1. "py .\release.py" to run the code
2. put the image of foreground in a folder named "img"
3. put the trimap of the image in a folder named "trimap"
4. can change the image name in the 19th of the code